(() => {
'use strict';
const $ = s => document.querySelector(s);
const el = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; };
const esc = s => String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const nf = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });
const compact = new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 });
const COLORS = ['#22f3ff', '#ff2bd6', '#b6ff3b', '#9d5cff', '#ffb02e'];
const PAGE = 25;
const amin = a => { let m = Infinity; for (const v of a) if (v < m) m = v; return m; };
const amax = a => { let m = -Infinity; for (const v of a) if (v > m) m = v; return m; };
const normAr = s => String(s).trim().replace(/\s+/g, ' ').replace(/[\u064B-\u0652\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').toLowerCase();

/* ---------- Storage (server API) ---------- */
const API = (() => {
  const raw = window.__API_BASE__ || '';
  const local = ['localhost', '127.0.0.1', '', '[::1]'].includes(location.hostname);
  if (raw.startsWith('__PORT_')) return local ? 'http://localhost:8000' : '';
  return raw;
})();
const enc = v => JSON.stringify(v, function (k, val) { const o = this[k]; return o instanceof Date ? { __d: +o } : val; });
const dec = t => JSON.parse(t, (k, v) => (v && typeof v === 'object' && '__d' in v && Object.keys(v).length === 1) ? new Date(v.__d) : v);
async function req(path, opt = {}, ms = 90000) {
  for (let a = 0; ; a++) {
    try { return await req1(path, opt, ms); }
    catch (e) { if (a >= 3 || /HTTP 4\d\d/.test(e.message)) throw e; await sleep(800 * (a + 1)); }
  }
}
async function req1(path, opt, ms) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try {
    const headers = { ...(opt.headers || {}) };
    if (AUTH.token) headers.Authorization = 'Bearer ' + AUTH.token;
    const r = await fetch(API + path, { ...opt, headers, signal: ctl.signal });
    if (r.status === 401 && !path.startsWith('/api/auth/')) { AUTH.expired(); }
    if (!r.ok) { const er = new Error('HTTP ' + r.status); er.status = r.status; try { er.detail = (await r.json()).detail; } catch {} throw er; }
    return dec(await r.text());
  } catch (e) { if (e.name === 'AbortError') throw new Error('HTTP timeout'); throw e; }
  finally { clearTimeout(t); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const AUTH = { token: null, user: null, expired() {} };
const CHUNK_BYTES = 1.5e6, PART_ROWS = 3000;
const REPS = new Map();
function getReport(id) {
  if (!REPS.has(id)) { const p = loadReport(id); REPS.set(id, p); p.catch(() => REPS.delete(id)); }
  return REPS.get(id);
}
async function loadReport(id) {
  const head = await req('/api/reports/' + encodeURIComponent(id) + '/head');
  for (let si = 0; si < head.sheets.length; si++) {
    const sh = head.sheets[si], rows = [];
    for (let start = 0; start < sh.total; start += PART_ROWS) {
      const p = await req(`/api/reports/${encodeURIComponent(id)}/part?si=${si}&start=${start}&count=${PART_ROWS}`);
      rows.push(...p.rows);
    }
    sh.rows = rows; delete sh.total;
  }
  return head;
}
async function putReport(r, onProgress = () => {}) {
  const id = encodeURIComponent(r.id), J = { 'Content-Type': 'application/json' };
  const total = r.sheets.reduce((a, s) => a + s.rows.length, 0) || 1; let sent = 0;
  await req(`/api/upload/${id}/begin`, { method: 'POST', headers: J, body: enc({ id: r.id, name: r.name, fileName: r.fileName, size: r.size, createdAt: r.createdAt, sheetNames: r.sheets.map(s => s.name), sheetHeaders: r.sheets.map(s => s.headers) }) });
  for (let si = 0; si < r.sheets.length; si++) {
    const rows = r.sheets[si].rows; let i = 0;
    while (i < rows.length) {
      let bytes = 0, j = i;
      while (j < rows.length && bytes < CHUNK_BYTES) { bytes += enc(rows[j]).length * 1.1 + 4; j++; }
      await req(`/api/upload/${id}/chunk`, { method: 'POST', headers: J, body: enc({ si, rows: rows.slice(i, j) }) });
      sent += j - i; i = j; onProgress(sent / total);
    }
  }
  await req(`/api/upload/${id}/finish`, { method: 'POST' });
  REPS.delete(r.id);
}
const DB = {
  all: () => req('/api/reports'),
  get: id => getReport(id),
  put: putReport,
  del: async id => { REPS.delete(id); return req('/api/reports/' + encodeURIComponent(id), { method: 'DELETE' }); },
};

/* ---------- State ---------- */
const st = { reports: [], current: null, sheet: 0, sortCol: -1, sortDir: 1, page: 0, q: '', chart: null, analysis: null };

/* ---------- Parsing ---------- */
function isEmpty(v) { return v === '' || v == null || (typeof v === 'string' && !v.trim()); }
const NIL = /^(لا ?شي[ءئ]?|لا ?يوجد|لا ?شيء|-+|—|nil|none)$/;
const arDig = s => s.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
function toDate(v) {
  if (v instanceof Date) return isNaN(v) ? null : v;
  if (typeof v !== 'string') return null;
  const t = arDig(v.trim()); let m;
  if ((m = t.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4}|\d{2})$/))) { const y = +m[3] < 100 ? 2000 + +m[3] : +m[3]; const d = new Date(y, +m[2] - 1, +m[1]); return d.getMonth() === +m[2] - 1 ? d : null; }
  if ((m = t.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/))) { const d = new Date(+m[1], +m[2] - 1, +m[3]); return d.getMonth() === +m[2] - 1 ? d : null; }
  return null;
}
function normalizeSheet(sh) {
  if (sh._norm) return sh; sh._norm = true;
  sh.headers.forEach((h, i) => {
    let n = 0, ok = 0;
    for (const r of sh.rows) { const v = r[i]; if (isEmpty(v)) continue; n++; if (toDate(v)) ok++; }
    if (n && ok / n >= .6) sh.rows.forEach(r => { const d = toDate(r[i]); if (d) r[i] = d; });
  });
  return sh;
}
function toNum(v) {
  if (typeof v === 'number') return isFinite(v) ? v : null;
  if (typeof v === 'string' && NIL.test(normAr(v))) return 0;
  if (typeof v === 'string') {
    const s = v.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[,\s٬]/g, '').replace('٫', '.');
    if (/^-?\d+(\.\d+)?%?$/.test(s)) return parseFloat(s);
  }
  return null;
}

function parseWorkbook(wb) {
  const sheets = [];
  wb.SheetNames.forEach(name => {
    const ws = wb.Sheets[name];
    let rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' });
    rows = rows.filter(r => r.some(c => !isEmpty(c)));
    if (!rows.length) return;
    // header row = the row with most filled cells among first 10
    let hi = 0, best = -1;
    rows.slice(0, 10).forEach((r, i) => { const n = r.filter(c => !isEmpty(c)).length; if (n > best) { best = n; hi = i; } });
    const width = amax(rows.map(r => r.length));
    const rawH = rows[hi];
    const headers = [];
    for (let i = 0; i < width; i++) {
      let h = isEmpty(rawH[i]) ? `عمود ${i + 1}` : String(rawH[i] instanceof Date ? rawH[i].toLocaleDateString('ar') : rawH[i]).trim();
      while (headers.includes(h)) h += ' ·';
      headers.push(h);
    }
    const body = rows.slice(hi + 1).map(r => { const o = new Array(width); for (let i = 0; i < width; i++) o[i] = r[i] === undefined ? '' : r[i]; return o; });
    // drop fully-empty columns
    const keep = headers.map((_, i) => body.some(r => !isEmpty(r[i])) || !isEmpty(rawH[i]));
    const H = headers.filter((_, i) => keep[i]);
    const B = body.map(r => r.filter((_, i) => keep[i]));
    const sh = normalizeSheet({ name, headers: H, rows: B }); delete sh._norm;
    sheets.push(sh);
  });
  return sheets;
}

function analyse(sheet) {
  const cols = sheet.headers.map((h, i) => {
    const vals = sheet.rows.map(r => r[i]).filter(v => !isEmpty(v));
    let nums = [], dates = 0;
    vals.forEach(v => { if (v instanceof Date) dates++; else { const n = toNum(v); if (n !== null) nums.push(n); } });
    const filled = vals.length;
    let type = 'text';
    if (filled && dates / filled >= .8) type = 'date';
    else if (filled && nums.length / filled >= .8) type = 'num';
    const c = { name: h, i, type, filled, empty: sheet.rows.length - filled, unique: new Set(vals.map(v => v instanceof Date ? +v : v)).size };
    if (type === 'num') {
      c.sum = nums.reduce((a, b) => a + b, 0);
      c.avg = nums.length ? c.sum / nums.length : 0;
      c.min = amin(nums); c.max = amax(nums);
    }
    if (type === 'date') {
      const ds = vals.filter(v => v instanceof Date).map(Number);
      c.min = new Date(amin(ds)); c.max = new Date(amax(ds));
    }
    return c;
  });
  return { cols };
}

const IDLIKE = /رقم|^id$|كود|code|هاتف|تلفون|جوال|phone/i;
function fmtCell(v, raw) {
  if (raw && typeof v === 'number') return String(v);
  if (v instanceof Date) return isNaN(v) ? '' : v.toLocaleDateString('en-CA');
  if (typeof v === 'number') return nf.format(v);
  return String(v);
}
function fmtDate(ts) { return new Date(ts).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' }); }
function fmtSize(b) { return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; }

/* ---------- Upload progress panel ---------- */
const UP = (() => {
  let shown = 0, target = 0, raf = 0, hideT = 0;
  const panel = () => $('#progress');
  const tick = () => {
    shown += (target - shown) * .3;
    if (Math.abs(target - shown) < .3) shown = target;
    $('#upPct').textContent = Math.round(shown) + '%';
    $('#bar').style.width = shown + '%';
    raf = shown !== target ? setTimeout(tick, 16) : 0;
  };
  const step = n => document.querySelectorAll('#upSteps li').forEach((li, k) => { li.classList.toggle('done', k < n || n === 3); li.classList.toggle('on', k === n && n !== 3); });
  return {
    start(name) {
      clearTimeout(hideT); shown = target = 0;
      const p = panel(); p.hidden = false; p.classList.remove('ok', 'err');
      $('#upFile').textContent = name; $('#upPct').textContent = '0%'; $('#bar').style.width = '0%';
      $('#drop').classList.add('busy'); step(0);
    },
    set(pct, label, s) {
      target = Math.max(target, Math.min(100, pct));
      if (label) $('#progressText').textContent = label;
      if (s != null) step(s);
      if (!raf) raf = setTimeout(tick, 16);
    },
    done(label) { this.set(100, label, 3); shown = 99.9; panel().classList.add('ok'); $('#drop').classList.remove('busy'); hideT = setTimeout(() => { panel().hidden = true; }, 2600); },
    fail(label) { const p = panel(); p.classList.add('err'); $('#progressText').textContent = label; $('#drop').classList.remove('busy'); hideT = setTimeout(() => { p.hidden = true; }, 6000); },
  };
})();
const frame = () => new Promise(r => setTimeout(r, 60));
function readFile(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onprogress = e => { if (e.lengthComputable) UP.set(e.loaded / e.total * 15, `جارٍ قراءة الملف… (${fmtSize(e.loaded)} من ${fmtSize(e.total)})`, 0); };
    fr.onload = () => res(fr.result); fr.onerror = () => rej(fr.error);
    fr.readAsArrayBuffer(file);
  });
}

/* ---------- Upload ---------- */
async function handleFile(file) {
  if (!file) return;
  if (!/\.(xlsx|xls|csv|ods)$/i.test(file.name)) return toast('صيغة غير مدعومة. استخدم xlsx أو xls أو csv', true);
  UP.start(file.name);
  UP.set(2, 'جارٍ قراءة الملف…', 0);
  try {
    const buf = await readFile(file);
    UP.set(18, 'جارٍ تحليل البيانات وترتيب الأعمدة…', 1);
    await frame();
    const wb = XLSX.read(buf, { type: 'array', cellDates: true, codepage: 65001 });
    await saveWorkbook(wb, file.name, file.size);
  } catch (e) {
    console.error(e);
    const msg = /HTTP|fetch/i.test(e.message) ? 'تعذّر حفظ التقرير على الخادم' : 'تعذّرت قراءة الملف، تأكد أنه ملف إكسل صالح';
    UP.fail(msg); toast(msg, true);
  } finally {
    $('#fileInput').value = '';
  }
}
async function saveWorkbook(wb, fileName, size) {
  UP.set(28, 'جارٍ تحليل البيانات وترتيب الأعمدة…', 1);
  await frame();
  const sheets = parseWorkbook(wb);
  if (!sheets.length) throw new Error('empty');
  const total = sheets.reduce((a, s) => a + s.rows.length, 0);
  UP.set(35, `جارٍ الحفظ في النظام… (0 من ${nf.format(total)} سجل)`, 2);
  const rep = { id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())), name: fileName.replace(/\.[^.]+$/, ''), fileName, size, createdAt: Date.now(), sheets };
  await DB.put(rep, p => UP.set(35 + p * 63, `جارٍ الحفظ في النظام… (${nf.format(Math.round(p * total))} من ${nf.format(total)} سجل)`, 2));
  UP.done(`تم الحفظ بنجاح — ${nf.format(total)} سجل`);
  await sleep(1400);
  invalidate(); await loadList();
  go('#/report/' + rep.id);
  toast(`تم حفظ التقرير «${rep.name}» — ${nf.format(total)} سجل`);
}

/* ---------- Sidebar ---------- */
async function loadList() {
  st.reports = (await DB.all()).sort((a, b) => b.createdAt - a.createdAt);
  renderList();
}
function renderList() {
  $('#reportCount').textContent = st.reports.filter(r => r.id !== 'manual-entries').length;
  if (!$('#filesView').classList.contains('hidden')) renderFiles();
}

/* ---------- Views ---------- */
function showUpload() {
  st.current = null; setNav('');
  hideViews();
  const u = $('#uploadView'); u.classList.remove('hidden'); restartAnim(u);
  $('#crumbs').innerHTML = 'لوحة الرفع';
  renderList(); closeSide();
}
async function openReport(id) {
  const r = await DB.get(id); if (!r) return go('#/upload');
  r.sheets.forEach(normalizeSheet);
  st.current = r; st.sheet = 0; resetTable(); setNav('files'); closeSide();
  hideViews();
  const v = $('#reportView'); v.classList.remove('hidden'); restartAnim(v);
  $('#crumbs').innerHTML = `<a href="#/files" style="color:inherit">الملفات المرفوعة</a> / <b>${esc(r.name)}</b>`;
  $('#rTitle').textContent = r.name;
  $('#rMeta').innerHTML = `<span>الملف: <b>${esc(r.fileName)}</b></span><span>الحجم: <b>${fmtSize(r.size)}</b></span><span>تاريخ الحفظ: <b>${fmtDate(r.createdAt)}</b></span>`;
  const tabs = $('#sheetTabs'); tabs.innerHTML = '';
  r.sheets.forEach((s, i) => {
    const t = el('button', 'tab' + (i === 0 ? ' active' : ''), `${esc(s.name)} <span style="opacity:.55">(${s.rows.length})</span>`);
    t.setAttribute('role', 'tab');
    t.onclick = () => { st.sheet = i; resetTable(); [...tabs.children].forEach((c, j) => c.classList.toggle('active', j === i)); renderSheet(); };
    tabs.append(t);
  });
  tabs.style.display = r.sheets.length > 1 ? '' : 'none';
  renderList(); renderSheet();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function restartAnim(n) { n.style.animation = 'none'; n.offsetHeight; n.style.animation = ''; }
function resetTable() { st.sortCol = -1; st.sortDir = 1; st.page = 0; st.q = ''; $('#tableSearch').value = ''; }

function renderSheet() {
  const s = st.current.sheets[st.sheet];
  st.analysis = analyse(s);
  renderKpis(s); renderSummary(); setupChart(); renderTable(); setupAgentColSel();
}

function renderKpis(s) {
  const k = $('#kpis'); k.innerHTML = '';
  const cols = st.analysis.cols;
  const nums = cols.filter(c => c.type === 'num');
  const list = [
    { l: 'إجمالي السجلات', v: s.rows.length, sub: 'صف بيانات', c: COLORS[0] },
    { l: 'عدد الأعمدة', v: s.headers.length, sub: `${nums.length} رقمي · ${cols.length - nums.length} نصي/تاريخ`, c: COLORS[1] },
  ];
  // prefer columns that look like totals
  const pref = nums.filter(c => !/رقم|^id$|no\.?$|serial|كود|code|هاتف|تلفون|phone|جوال/i.test(c.name)).sort((a, b) => score(b) - score(a)).slice(0, 3);
  pref.forEach((c, i) => { const avgOnly = /(سعر|price|rate|نسبة|معدل|%|عمر|age)/i.test(c.name); list.push(avgOnly ? { l: `متوسط «${c.name}»`, v: +c.avg.toFixed(2), sub: `من ${nf.format(c.min)} إلى ${nf.format(c.max)}`, c: COLORS[(i + 2) % COLORS.length] } : { l: `مجموع «${c.name}»`, v: c.sum, sub: `المتوسط ${nf.format(c.avg)}`, c: COLORS[(i + 2) % COLORS.length] }); });
  list.forEach((x, i) => {
    const d = el('div', 'kpi'); d.style.setProperty('--c', x.c); d.style.animationDelay = (i * 70) + 'ms';
    d.innerHTML = `<div class="kpi-label" title="${esc(x.l)}">${esc(x.l)}</div><div class="kpi-val" data-v="${x.v}">0</div><div class="kpi-sub">${esc(x.sub)}</div>`;
    k.append(d);
  });
  k.querySelectorAll('.kpi-val').forEach(countUp);
}
function score(c) { return (/(إجمالي|اجمالي|المجموع|total|amount|المبلغ|القيمة|مبيعات|sales|الراتب)/i.test(c.name) ? 1e15 : 0) + Math.abs(c.sum); }
function countUp(n) {
  const target = +n.dataset.v, t0 = performance.now(), dur = 1100;
  const big = Math.abs(target) >= 1e6;
  const step = t => {
    const p = Math.max(0, Math.min(1, (t - t0) / dur)), e = 1 - Math.pow(1 - p, 3), v = target * e;
    n.textContent = big ? compact.format(v) : nf.format(Number.isInteger(target) ? Math.round(v) : v);
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
  if (big) n.title = nf.format(target);
}

function renderSummary() {
  const box = $('#colSummary'); box.innerHTML = '';
  const tl = { num: 'رقمي', text: 'نصي', date: 'تاريخ' };
  st.analysis.cols.forEach(c => {
    let stats = `filled ${c.filled} · unique ${c.unique}`;
    if (c.type === 'num') stats = `min ${nf.format(c.min)} · max ${nf.format(c.max)} · avg ${nf.format(c.avg)}`;
    if (c.type === 'date') stats = `${c.min.toLocaleDateString('en-CA')} → ${c.max.toLocaleDateString('en-CA')}`;
    if (c.empty) stats += ` · empty ${c.empty}`;
    box.append(el('div', 'cs', `<div class="cs-name" title="${esc(c.name)}">${esc(c.name)}</div><span class="cs-type t-${c.type}">${tl[c.type]}</span><div class="cs-stats">${stats}</div>`));
  });
}

/* ---------- Chart ---------- */
function setupChart() {
  const cols = st.analysis.cols;
  const lab = $('#labelCol'), val = $('#valueCol');
  const texts = cols.filter(c => c.type !== 'num');
  const nums = cols.filter(c => c.type === 'num');
  lab.innerHTML = `<option value="-1">حسب رقم الصف</option>` + texts.map(c => `<option value="${c.i}">${esc(c.name)}</option>`).join('');
  val.innerHTML = `<option value="-1">عدد السجلات</option>` + nums.map(c => `<option value="${c.i}">${esc(c.name)}</option>`).join('');
  // sensible defaults: text column with low cardinality, numeric with highest score
  const goodLabel = texts.filter(c => c.type === 'text' && c.unique > 1 && c.unique <= 40).sort((a, b) => a.unique - b.unique)[0] || texts[0];
  if (goodLabel) lab.value = goodLabel.i;
  const goodVal = nums.filter(c => !/رقم|^id$|كود|code|هاتف|phone/i.test(c.name)).sort((a, b) => score(b) - score(a))[0];
  if (goodVal) val.value = goodVal.i;
  drawChart();
}
function drawChart() {
  const s = st.current.sheets[st.sheet];
  const li = +$('#labelCol').value, vi = +$('#valueCol').value, type = $('#chartType').value;
  const agg = new Map();
  s.rows.forEach((r, idx) => {
    const k = li < 0 ? String(idx + 1) : (isEmpty(r[li]) ? '(فارغ)' : fmtCell(r[li]));
    const v = vi < 0 ? 1 : (toNum(r[vi]) || 0);
    agg.set(k, (agg.get(k) || 0) + v);
  });
  let entries = [...agg.entries()];
  if (li >= 0) entries.sort((a, b) => b[1] - a[1]);
  const limit = type === 'doughnut' ? 8 : 20;
  if (entries.length > limit) {
    if (li >= 0) { const rest = entries.slice(limit - 1).reduce((a, e) => a + e[1], 0); entries = entries.slice(0, limit - 1).concat([['أخرى', rest]]); }
    else entries = entries.slice(0, limit);
  }
  const labels = entries.map(e => e[0]), data = entries.map(e => e[1]);
  if (st.chart) st.chart.destroy();
  const ctx = $('#chart').getContext('2d');
  const g = ctx.createLinearGradient(0, 0, 0, 320); g.addColorStop(0, 'rgba(255,43,214,.9)'); g.addColorStop(1, 'rgba(34,243,255,.25)');
  const isD = type === 'doughnut';
  st.chart = new Chart(ctx, {
    type,
    data: { labels, datasets: [{
      label: vi < 0 ? 'عدد السجلات' : s.headers[vi], data,
      backgroundColor: isD ? labels.map((_, i) => COLORS[i % COLORS.length] + 'cc') : (type === 'line' ? 'rgba(34,243,255,.12)' : g),
      borderColor: isD ? '#05040b' : '#22f3ff', borderWidth: isD ? 3 : 2,
      borderRadius: type === 'bar' ? 6 : 0, fill: type === 'line', tension: .35,
      pointBackgroundColor: '#ff2bd6', pointRadius: 3, hoverOffset: 10,
    }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 1100, easing: 'easeOutQuart' },
      plugins: {
        legend: { display: isD, position: 'bottom', rtl: true, labels: { color: '#cfcaf5', font: { family: 'IBM Plex Sans Arabic' }, boxWidth: 12 } },
        tooltip: { rtl: true, backgroundColor: '#100d22', borderColor: '#22f3ff', borderWidth: 1, titleFont: { family: 'IBM Plex Sans Arabic' }, bodyFont: { family: 'JetBrains Mono' }, callbacks: { label: c => ' ' + nf.format(c.parsed.y ?? c.parsed) } },
      },
      scales: isD ? {} : {
        x: { reverse: true, ticks: { color: '#9a94c4', font: { family: 'IBM Plex Sans Arabic', size: 11 }, maxRotation: 50 }, grid: { color: 'rgba(140,120,255,.07)' } },
        y: { position: 'right', ticks: { color: '#9a94c4', font: { family: 'JetBrains Mono', size: 11 }, callback: v => compact.format(v) }, grid: { color: 'rgba(140,120,255,.1)' } },
      },
    },
  });
}

/* ---------- Table ---------- */
function filteredRows() {
  const s = st.current.sheets[st.sheet];
  let rows = s.rows.map((r, i) => ({ r, i }));
  const q = st.q.trim().toLowerCase();
  if (q) rows = rows.filter(x => x.r.some(c => (fmtCell(c) + (typeof c === 'number' ? ' ' + c : '')).toLowerCase().includes(q)));
  if (st.sortCol >= 0) {
    const c = st.sortCol, d = st.sortDir;
    rows.sort((a, b) => {
      const x = a.r[c], y = b.r[c];
      const nx = x instanceof Date ? +x : toNum(x), ny = y instanceof Date ? +y : toNum(y);
      if (nx !== null && ny !== null) return (nx - ny) * d;
      if (isEmpty(x)) return 1; if (isEmpty(y)) return -1;
      return String(x).localeCompare(String(y), 'ar') * d;
    });
  }
  return rows;
}
function renderTable() {
  const s = st.current.sheets[st.sheet], cols = st.analysis.cols;
  const rows = filteredRows();
  const pages = Math.max(1, Math.ceil(rows.length / PAGE));
  st.page = Math.min(st.page, pages - 1);
  const slice = rows.slice(st.page * PAGE, st.page * PAGE + PAGE);
  const q = st.q.trim();
  const hl = t => { const e = esc(t); if (!q) return e; const re = new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'); return e.replace(re, '<mark>$1</mark>'); };
  let h = '<thead><tr><th>#</th>' + s.headers.map((x, i) => `<th data-c="${i}" class="${st.sortCol === i ? 'sorted' : ''}">${esc(x)}<span class="arr">${st.sortCol === i ? (st.sortDir > 0 ? '▲' : '▼') : '⇅'}</span></th>`).join('') + '<th class="row-acts">إجراءات</th></tr></thead><tbody>';
  if (!slice.length) h += `<tr><td colspan="${s.headers.length + 2}" class="no-rows">${s.rows.length ? 'لا توجد بيانات مطابقة للبحث' : 'لا توجد سجلات بعد. اضغط «+ إضافة سجل».'}</td></tr>`;
  const fl = st.flash && st.flash.id === st.current.id && st.flash.si === st.sheet ? st.flash.ri : -1; st.flash = null;
  slice.forEach(({ r, i }) => {
    h += `<tr${i === fl ? ' class="flash"' : ''}><td class="idx">${i + 1}</td>` + s.headers.map((_, j) => { const c = r[j] ?? ''; const raw = IDLIKE.test(s.headers[j]); return `<td class="${cols[j] && cols[j].type !== 'text' ? 'num' : ''}" title="${esc(fmtCell(c, raw))}">${hl(fmtCell(c, raw))}</td>`; }).join('') + actCell(i) + '</tr>';
  });
  $('#dataTable').innerHTML = h + '</tbody>';
  $('#dataTable').querySelectorAll('th[data-c]').forEach(th => th.onclick = () => {
    const c = +th.dataset.c; if (st.sortCol === c) st.sortDir *= -1; else { st.sortCol = c; st.sortDir = 1; } renderTable();
  });
  const from = rows.length ? st.page * PAGE + 1 : 0, to = Math.min(rows.length, (st.page + 1) * PAGE);
  $('#pager').innerHTML = `<span>عرض ${from}–${to} من ${rows.length} سجل</span><div class="pg"><button class="btn" id="prev" ${st.page === 0 ? 'disabled' : ''}>السابق</button><span style="align-self:center;font-family:var(--font-m)">${st.page + 1} / ${pages}</span><button class="btn" id="next" ${st.page >= pages - 1 ? 'disabled' : ''}>التالي</button></div>`;
  $('#prev').onclick = () => { st.page--; renderTable(); };
  $('#next').onclick = () => { st.page++; renderTable(); };
}

/* ---------- Actions ---------- */
function exportCsv() {
  const s = st.current.sheets[st.sheet];
  const rows = filteredRows().map(x => x.r.map(fmtCell));
  const csv = [s.headers, ...rows].map(r => r.map(c => /[",\n]/.test(c) ? `"${String(c).replace(/"/g, '""')}"` : c).join(',')).join('\n');
  const a = el('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
  a.download = `${st.current.name}-${s.name}.csv`; a.click(); URL.revokeObjectURL(a.href);
}
async function deleteReport() {
  if (!st.current || !await ask('حذف الملف؟', `سيتم حذف الملف «${st.current.name}» وكل سجلاته نهائياً من النظام.`, 'حذف الملف')) return;
  const name = st.current.name;
  await DB.del(st.current.id); invalidate(); await loadList(); go('#/files'); toast(`تم حذف «${name}»`);
}

function demo() {
  const agents = ['خالد عباس', 'محمد الحمادي', 'سالم باوزير', 'أحمد الشامي', 'علي المقطري', 'فهد العولقي'];
  let seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  const pick = a => a[Math.floor(rnd() * a.length)];
  const led = [['التاريخ', 'رقم السند', 'نوع السند', 'الوكيل', 'البيان', 'مدين', 'دائن']];
  for (let i = 0; i < 140; i++) {
    const d = new Date(2026, Math.floor(rnd() * 9), 1 + Math.floor(rnd() * 27));
    const t = rnd() < .55 ? 'فاتورة مبيعات' : (rnd() < .8 ? 'سند قبض' : 'سند صرف');
    const amt = Math.round((50 + rnd() * 1950) / 5) * 5;
    led.push([d, 'SN-' + (5000 + i), t, pick(agents), t === 'فاتورة مبيعات' ? 'بضاعة مسلّمة' : t === 'سند قبض' ? 'تحصيل نقدي' : 'مرتجع / تسوية', t === 'سند قبض' ? '' : amt, t === 'سند قبض' ? amt : '']);
  }
  const products = [['لابتوب', 420], ['هاتف ذكي', 180], ['شاشة', 140], ['طابعة', 95], ['سماعات', 25]];
  const sales = [['رقم الفاتورة', 'التاريخ', 'الوكيل', 'المنتج', 'الكمية', 'سعر الوحدة', 'الإجمالي']];
  for (let i = 0; i < 60; i++) {
    const p = pick(products), q = 1 + Math.floor(rnd() * 10);
    sales.push([`INV-${1000 + i}`, new Date(2026, Math.floor(rnd() * 9), 1 + Math.floor(rnd() * 27)), pick(agents), p[0], q, p[1], q * p[1]]);
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(led, { cellDates: true }), 'حركة الوكلاء');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sales, { cellDates: true }), 'المبيعات');
  UP.start('كشف الوكلاء التجريبي.xlsx'); UP.set(10, 'جارٍ إنشاء ملف تجريبي…', 0);
  setTimeout(async () => {
    try {
      const buf = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
      const wb2 = XLSX.read(buf, { type: 'array', cellDates: true });
      await saveWorkbook(wb2, 'كشف الوكلاء التجريبي.xlsx', buf.byteLength);
    } catch (e) { console.error(e); UP.fail('تعذّر حفظ التقرير على الخادم'); }
  }, 300);
}


/* ---------- Auth & WebAuthn (passkeys) ---------- */
const b64u = {
  enc: buf => { const b = new Uint8Array(buf); let s = ''; for (const x of b) s += String.fromCharCode(x); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); },
  dec: str => { const s = atob(str.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((str.length + 3) % 4)); const b = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i); return b.buffer; },
};
const postJ = (path, body) => req(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }, 30000);
const BIO = { api: false, platform: false, checked: false };

async function checkBioSupport() {
  BIO.api = !!(window.PublicKeyCredential && navigator.credentials && navigator.credentials.create && navigator.credentials.get && window.isSecureContext);
  if (BIO.api && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) {
    try { BIO.platform = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable(); } catch { BIO.platform = false; }
  }
  BIO.checked = true;
  const box = $('#bioSupport'), t = $('#bioSupportText');
  box.classList.remove('no', 'maybe');
  if (!BIO.api) { box.classList.add('no'); t.textContent = 'هذا المتصفح لا يدعم الدخول بالبصمة أو الوجه (WebAuthn)'; }
  else if (!BIO.platform) { box.classList.add('maybe'); t.textContent = 'المتصفح يدعم WebAuthn، لكن لم يُعثر على بصمة أو Face ID مفعّل في هذا الجهاز'; }
  else t.textContent = 'المتصفح والجهاز يدعمان الدخول بالبصمة أو الوجه';
  $('#bioLogin').hidden = $('#bioOr').hidden = !BIO.api;
  return BIO;
}

function bioError(e) {
  const n = e && e.name;
  if (n === 'NotAllowedError') return 'تم إلغاء العملية أو انتهى وقتها. إذا كانت الصفحة داخل إطار معاينة، افتحها في تبويب مستقل.';
  if (n === 'InvalidStateError') return 'هذا الجهاز مسجّل مسبقاً لهذا الحساب.';
  if (n === 'SecurityError') return 'المتصفح منع البصمة في هذه الصفحة (يتطلب نطاقاً آمناً). افتح النظام في تبويب مستقل.';
  if (n === 'NotSupportedError') return 'هذا الجهاز لا يدعم نوع المصادقة المطلوب.';
  if (e && e.status === 401) return 'لم يتم التعرف على هذه البصمة. سجّل الدخول بكلمة المرور ثم سجّل البصمة.';
  if (e && e.status === 400 && /origin/.test(e.detail || '')) return 'هذا النطاق غير مسموح للبصمة.';
  return 'تعذّر إكمال التحقق بالبصمة. حاول مرة أخرى.';
}

async function enrollPasskey() {
  const opts = await postJ('/api/auth/passkey/register/options', { origin: location.origin });
  const pk = {
    ...opts,
    challenge: b64u.dec(opts.challenge),
    user: { ...opts.user, id: b64u.dec(opts.user.id) },
    excludeCredentials: (opts.excludeCredentials || []).map(c => ({ ...c, id: b64u.dec(c.id) })),
  };
  const cred = await navigator.credentials.create({ publicKey: pk });
  const r = cred.response;
  const body = {
    id: cred.id, rawId: b64u.enc(cred.rawId), type: cred.type,
    authenticatorAttachment: cred.authenticatorAttachment || undefined,
    clientExtensionResults: cred.getClientExtensionResults ? cred.getClientExtensionResults() : {},
    response: { clientDataJSON: b64u.enc(r.clientDataJSON), attestationObject: b64u.enc(r.attestationObject), transports: r.getTransports ? r.getTransports() : [] },
  };
  const label = /iPhone|iPad/.test(navigator.userAgent) ? 'iPhone / iPad' : /Android/.test(navigator.userAgent) ? 'هاتف أندرويد' : /Mac/.test(navigator.userAgent) ? 'Mac' : /Windows/.test(navigator.userAgent) ? 'Windows Hello' : 'جهاز';
  return postJ('/api/auth/passkey/register/verify', { credential: body, label });
}

async function passkeyLogin(username) {
  const opts = await postJ('/api/auth/passkey/login/options', { origin: location.origin, username: username || '' });
  const pk = {
    challenge: b64u.dec(opts.challenge), rpId: opts.rpId, timeout: opts.timeout, userVerification: opts.userVerification,
    allowCredentials: (opts.allowCredentials || []).map(c => ({ ...c, id: b64u.dec(c.id) })),
  };
  const cred = await navigator.credentials.get({ publicKey: pk });
  const r = cred.response;
  const body = {
    id: cred.id, rawId: b64u.enc(cred.rawId), type: cred.type,
    authenticatorAttachment: cred.authenticatorAttachment || undefined,
    clientExtensionResults: cred.getClientExtensionResults ? cred.getClientExtensionResults() : {},
    response: { clientDataJSON: b64u.enc(r.clientDataJSON), authenticatorData: b64u.enc(r.authenticatorData), signature: b64u.enc(r.signature), userHandle: r.userHandle ? b64u.enc(r.userHandle) : null },
  };
  return postJ('/api/auth/passkey/login/verify', { key: opts.key, credential: body });
}

function setMsg(id, m, ok) { const e = $(id); e.textContent = m || ''; e.classList.toggle('ok', !!ok); }
function busy(btn, on) { btn.disabled = on; btn.classList.toggle('loading', on); }
function shake() { const c = $('#loginForm'); c.classList.remove('shake'); void c.offsetWidth; c.classList.add('shake'); }

let started = false;
function onAuthed(res, viaBio) {
  AUTH.token = res.token; AUTH.user = res.user;
  $('#uName').textContent = res.user; $('#uAvatar').textContent = (res.user[0] || 'A').toUpperCase();
  $('#lgPass').value = '';
  $('#auth').classList.add('off');
  refreshMe();
  loadTrashCount();
  if (!started) { started = true; startApp(); } else { invalidate(); loadList().then(route).catch(() => {}); }
  if (!viaBio && !res.passkeys && BIO.api) setTimeout(() => openSec(true), 700);
}
async function refreshMe() {
  try {
    const me = await req('/api/auth/me', {}, 20000);
    const n = me.passkeys.length;
    $('#uSub').textContent = n ? `البصمة مفعّلة · ${n} جهاز` : 'البصمة غير مفعّلة';
    renderPk(me.passkeys); return me;
  } catch { return null; }
}
function renderPk(list) {
  const box = $('#pkList'); box.innerHTML = '';
  for (const k of list) {
    const d = new Date(k.createdAt);
    const row = el('div', 'pk', `<b>${esc(k.label || 'جهاز')}</b><span>${d.toISOString().slice(0, 10)}${k.lastUsed ? ' · آخر استخدام ' + new Date(k.lastUsed).toISOString().slice(0, 10) : ''}</span>`);
    const del = el('button', 'btn btn-ghost', 'حذف');
    del.onclick = async () => { if (!confirm('حذف هذه البصمة من الحساب؟')) return; await req('/api/auth/passkey/' + encodeURIComponent(k.id), { method: 'DELETE' }); refreshMe(); };
    row.appendChild(del); box.appendChild(row);
  }
}
function openSec(firstTime) {
  setMsg('#secMsg', '');
  $('#secTitle').textContent = firstTime ? 'فعّل الدخول بالبصمة أو الوجه' : 'البصمة والأمان';
  $('#enrollLater').textContent = firstTime ? 'لاحقاً' : 'إغلاق';
  $('#enrollBtn').textContent = $('#pkList').children.length ? 'إضافة جهاز آخر' : 'تسجيل البصمة / الوجه';
  $('#enrollBtn').hidden = !BIO.api;
  if (!BIO.api) setMsg('#secMsg', 'هذا المتصفح لا يدعم WebAuthn، لذلك لا يمكن تسجيل البصمة عليه.');
  $('#pwBox').open = false;
  $('#secModal').hidden = false;
}
const closeSec = () => { $('#secModal').hidden = true; };

function setupAuth() {
  AUTH.expired = () => {
    if (!AUTH.token) return;
    AUTH.token = null; $('#auth').classList.remove('off');
    setMsg('#lgMsg', 'انتهت الجلسة، يرجى تسجيل الدخول مرة أخرى');
  };
  checkBioSupport();
  $('#loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    const btn = $('#lgBtn'); busy(btn, true); setMsg('#lgMsg', '');
    try {
      const res = await postJ('/api/auth/login', { username: $('#lgUser').value.trim(), password: $('#lgPass').value });
      onAuthed(res, false);
    } catch (er) {
      shake();
      setMsg('#lgMsg', er.status === 401 ? 'اسم المستخدم أو كلمة المرور غير صحيحة' : er.status === 429 ? 'محاولات كثيرة، انتظر 5 دقائق ثم حاول' : 'تعذّر الاتصال بالخادم');
    } finally { busy(btn, false); }
  });
  $('#bioLogin').addEventListener('click', async () => {
    const btn = $('#bioLogin'); busy(btn, true); setMsg('#lgMsg', 'ضع إصبعك أو انظر إلى الكاميرا…', true);
    try { onAuthed(await passkeyLogin($('#lgUser').value.trim()), true); }
    catch (er) { console.warn(er); shake(); setMsg('#lgMsg', bioError(er)); }
    finally { busy(btn, false); }
  });
  $('#enrollBtn').addEventListener('click', async () => {
    const btn = $('#enrollBtn'); busy(btn, true); $('.bio-orb').classList.add('scan'); setMsg('#secMsg', 'أكمل البصمة أو التعرف على الوجه في النافذة الظاهرة…', true);
    try {
      await enrollPasskey();
      setMsg('#secMsg', 'تم ربط البصمة بالحساب بنجاح. يمكنك الآن الدخول بها.', true);
      await refreshMe(); toast('تم تفعيل الدخول بالبصمة / الوجه');
      $('#enrollBtn').textContent = 'إضافة جهاز آخر'; $('#enrollLater').textContent = 'تم';
    } catch (er) { console.warn(er); setMsg('#secMsg', bioError(er)); }
    finally { busy(btn, false); $('.bio-orb').classList.remove('scan'); }
  });
  $('#enrollLater').onclick = closeSec; $('#secClose').onclick = closeSec;
  $('#secModal').addEventListener('click', e => { if (e.target.id === 'secModal') closeSec(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#secModal').hidden) closeSec(); });
  $('#secBtn').onclick = async () => { await refreshMe(); openSec(false); };
  $('#logoutBtn').onclick = async () => {
    try { await postJ('/api/auth/logout'); } catch {}
    AUTH.token = null; $('#auth').classList.remove('off'); setMsg('#lgMsg', 'تم تسجيل الخروج', true); closeSide && closeSide();
  };
  $('#pwForm').addEventListener('submit', async e => {
    e.preventDefault();
    try { await postJ('/api/auth/password', { old: $('#pwOld').value, new: $('#pwNew').value }); $('#pwOld').value = $('#pwNew').value = ''; setMsg('#secMsg', 'تم تغيير كلمة المرور', true); }
    catch (er) { setMsg('#secMsg', er.status === 403 ? 'كلمة المرور الحالية غير صحيحة' : 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل'); }
  });
  setTimeout(() => $('#lgUser').focus(), 300);
}
function startApp() {
  loadList().then(() => { dataset().catch(() => {}); route(); }).catch(e => { console.error(e); toast('تعذّر الاتصال بخادم الحفظ', true); route(); });
}

/* ---------- Records: manual add / edit / delete / trash ---------- */
const ICON_EDIT = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M4 20h4L19 9l-4-4L4 16z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
const ICON_DEL = '<svg viewBox="0 0 24 24" width="15" height="15"><path d="M4 7h16M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const actCell = i => `<td class="row-acts"><button type="button" data-act="edit" data-i="${i}" title="تعديل" aria-label="تعديل السجل">${ICON_EDIT}</button><button type="button" class="del" data-act="del" data-i="${i}" title="حذف" aria-label="حذف السجل">${ICON_DEL}</button></td>`;
const J = { 'Content-Type': 'application/json' };
const pad2 = n => String(n).padStart(2, '0');
const isoDay = d => d instanceof Date && !isNaN(d) ? `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}` : '';

function fieldKinds(sh) {
  const an = analyse(sh);
  return sh.headers.map((h, i) => {
    const t = an.cols[i] ? an.cols[i].type : 'text';
    if (/تاريخ|date/i.test(h) || t === 'date') return 'date';
    if (IDLIKE.test(h)) return 'id';
    if (t === 'num' || MONEY_RE.test(h) || /الدفع|المتبقي|المبلغ|مدين|دائن|رصيد/.test(h)) return 'num';
    return 'text';
  });
}
function agentIndex(rep, si) {
  const sh = rep.sheets[si];
  const ov = rep.agentCols && rep.agentCols[si];
  if (ov !== undefined && ov !== null) return +ov;
  return detectAgentCol(analyse(sh).cols);
}
function buildForm(form, rep, si, row) {
  const sh = rep.sheets[si], kinds = fieldKinds(sh), ai = agentIndex(rep, si);
  form.innerHTML = '';
  form.dataset.kinds = JSON.stringify(kinds);
  sh.headers.forEach((h, i) => {
    const v = row ? row[i] : '';
    const k = kinds[i];
    const lab = el('label', 'field' + (/ملاحظ/.test(h) ? ' wide' : ''));
    let input;
    if (k === 'date') { input = el('input'); input.type = 'date'; input.value = v instanceof Date ? isoDay(v) : (toDate(v) ? isoDay(toDate(v)) : ''); if (!row && !input.value) input.value = isoDay(new Date()); }
    else { input = el('input'); input.type = 'text'; if (k === 'num') { input.inputMode = 'decimal'; input.dir = 'ltr'; } input.value = isEmpty(v) ? '' : (typeof v === 'number' ? String(v) : String(v)); }
    if (i === ai && DS) { input.setAttribute('list', 'agentNames'); }
    input.name = 'f' + i; input.dataset.i = i;
    lab.innerHTML = `<span>${esc(h)}<span class="t">${k === 'date' ? 'تاريخ' : k === 'num' ? 'رقم' : ''}</span></span>`;
    lab.append(input); form.append(lab);
  });
  if (DS && !document.getElementById('agentNames')) {
    const dl = el('datalist'); dl.id = 'agentNames';
    dl.innerHTML = DS.agents.slice(0, 2000).map(a => `<option value="${esc(a.name)}">`).join('');
    document.body.append(dl);
  }
}
function readForm(form) {
  const kinds = JSON.parse(form.dataset.kinds || '[]');
  return [...form.querySelectorAll('input')].map((inp, i) => {
    const v = inp.value.trim(), k = kinds[i];
    if (!v) return '';
    if (k === 'date') { const [y, m, d] = v.split('-').map(Number); return new Date(y, m - 1, d); }
    if (k === 'num') { const n = Number(arDig(v).replace(/[,٬\s]/g, '').replace('٫', '.')); return isFinite(n) ? n : v; }
    if (k === 'id' && /^\d+$/.test(arDig(v)) && arDig(v).length < 15) return Number(arDig(v));
    return v;
  });
}

/* modal helpers */
function ask(title, msg, okLabel = 'تأكيد') {
  return new Promise(res => {
    $('#askTitle').textContent = title; $('#askMsg').textContent = msg; $('#askOk').textContent = okLabel;
    const m = $('#askModal'); m.hidden = false; setTimeout(() => $('#askNo').focus(), 50);
    const done = v => { m.hidden = true; $('#askOk').onclick = $('#askNo').onclick = null; res(v); };
    $('#askOk').onclick = () => done(true); $('#askNo').onclick = () => done(false);
    m.onclick = e => { if (e.target === m) done(false); };
  });
}

/* server ops + keep the local cache in sync */
async function addRow(rep, si, row) {
  const r = await req(`/api/reports/${encodeURIComponent(rep.id)}/rows`, { method: 'POST', headers: J, body: enc({ si, row }) });
  rep.sheets[si].rows.push(row); afterChange(); return r.ri;
}
async function editRow(rep, si, ri, row) {
  await req(`/api/reports/${encodeURIComponent(rep.id)}/rows`, { method: 'PUT', headers: J, body: enc({ si, ri, row }) });
  rep.sheets[si].rows[ri] = row; afterChange();
}
async function deleteRow(rep, si, ri) {
  await req(`/api/reports/${encodeURIComponent(rep.id)}/rows/delete`, { method: 'POST', headers: J, body: enc({ si, ri }) });
  rep.sheets[si].rows.splice(ri, 1); afterChange(); loadTrashCount();
}
function afterChange() {
  DS = null; const dl = document.getElementById('agentNames'); if (dl) dl.remove();
  DB.all().then(list => { st.reports = list.sort((a, b) => b.createdAt - a.createdAt); renderList(); }).catch(() => {});
}
async function loadTrashCount() {
  try { const t = await req('/api/trash', {}, 30000); $('#trashCount').textContent = t.length; return t; } catch { return null; }
}
async function confirmDelete(rep, si, ri) {
  const sh = rep.sheets[si], row = sh.rows[ri];
  const preview = sh.headers.map((h, i) => isEmpty(row[i]) ? '' : `${h}: ${fmtCell(row[i], IDLIKE.test(h))}`).filter(Boolean).slice(0, 4).join(' · ');
  if (!await ask('حذف السجل؟', `سيُنقل هذا السجل إلى قسم «السجلات المحذوفة» ويمكنك استعادته لاحقاً.\n${preview}`, 'نقل إلى المحذوفات')) return false;
  toast('جارٍ الحذف…');
  try { await deleteRow(rep, si, ri); toast('تم نقل السجل إلى السجلات المحذوفة'); refreshCurrent(); return true; }
  catch (e) { onErr(e); return false; }
}
let REC = null;
function openRecord(rep, si, ri) {
  const sh = rep.sheets[si], isNew = ri == null;
  REC = { rep, si, ri };
  $('#recTitle').textContent = isNew ? 'إضافة سجل جديد' : 'تعديل السجل';
  $('#recSrc').textContent = `${rep.name} / ${sh.name}` + (isNew ? '' : ` — السجل رقم ${ri + 1}`);
  $('#recSave').textContent = isNew ? 'حفظ السجل' : 'حفظ التعديلات';
  $('#recDel').hidden = isNew;
  buildForm($('#recForm'), rep, si, isNew ? null : sh.rows[ri]);
  $('#recModal').hidden = false;
  setTimeout(() => { const f = $('#recForm input'); f && f.focus(); }, 60);
}
const closeRecord = () => { $('#recModal').hidden = true; REC = null; };
async function saveRecord() {
  if (!REC) return;
  const { rep, si, ri } = REC, row = readForm($('#recForm'));
  if (row.every(isEmpty)) return toast('أدخل قيمة واحدة على الأقل', true);
  const btn = $('#recSave'); btn.disabled = true; btn.classList.add('loading');
  try {
    if (ri == null) { const nri = await addRow(rep, si, row); toast('تمت إضافة السجل'); st.flash = { id: rep.id, si, ri: nri }; }
    else { await editRow(rep, si, ri, row); toast('تم حفظ التعديلات'); st.flash = { id: rep.id, si, ri }; }
    closeRecord(); refreshCurrent();
  } catch (e) { onErr(e); }
  finally { btn.disabled = false; }
}
function refreshCurrent() {
  const h = decodeURIComponent(location.hash.slice(1) || '/'); const [, view, ...rest] = h.split('/'); const arg = rest.join('/');
  if (view === 'report' && st.current) {
    const tabs = $('#sheetTabs').children;
    st.current.sheets.forEach((s, i) => { if (tabs[i]) tabs[i].innerHTML = `${esc(s.name)} <span style="opacity:.55">(${s.rows.length})</span>`; });
    renderSheet();
  } else if (view === 'agent') showAgent(arg, true).catch(onErr);
  else if (view === 'ledger') showLedger(true).catch(onErr);
  else if (view === 'entry') renderRecent();
  else if (view === 'agents') showAgents().catch(onErr);
}

/* ---------- Files page ---------- */
const isManual = r => r.id === 'manual-entries';
async function showFiles() {
  st.current = null; setNav('files');
  showView('#filesView'); $('#crumbs').innerHTML = '<b>الملفات المرفوعة</b>';
  if (!st.reports.length) await loadList();
  renderFiles();
}
function renderFiles() {
  const q = normAr($('#fileSearch').value || '');
  const all = st.reports.filter(r => !(isManual(r) && !r.rowCount));
  const files = all.filter(r => !q || normAr(r.name + ' ' + r.fileName).includes(q));
  const up = all.filter(r => !isManual(r));
  kpiRow($('#fKpis'), [
    { l: 'عدد الملفات المرفوعة', v: up.length },
    { l: 'إجمالي السجلات', v: all.reduce((a, r) => a + r.rowCount, 0), sub: 'في كل الملفات' },
    { l: 'الحجم الإجمالي', v: fmtSize(up.reduce((a, r) => a + (r.size || 0), 0)) },
    { l: 'آخر رفع', v: up.length ? new Date(Math.max(...up.map(r => r.createdAt))).toLocaleDateString('en-CA') : '—' },
  ]);
  const box = $('#fileList');
  if (!files.length) { box.innerHTML = emptyState(all.length ? 'لا يوجد ملف بهذا الاسم.' : 'لم ترفع أي ملف بعد. اضغط «رفع ملف جديد» للبدء.'); box.style.display = 'block'; return; }
  box.style.display = ''; box.innerHTML = '';
  files.forEach((r, i) => {
    const ext = isManual(r) ? 'يدوي' : ((r.fileName.match(/\.([a-z0-9]+)$/i) || [, 'XLS'])[1]).toUpperCase();
    const c = el('div', 'f-card' + (isManual(r) ? ' manual' : ''));
    c.tabIndex = 0; c.setAttribute('role', 'link'); c.style.animationDelay = Math.min(i * 50, 500) + 'ms';
    c.innerHTML = `<div class="f-top"><div class="f-ico">${esc(ext)}</div><div style="min-width:0"><div class="f-name">${esc(r.name)}</div><div class="f-file">${esc(isManual(r) ? 'سجلات أُدخلت يدوياً' : r.fileName)}</div></div></div>
      <div class="f-stats"><div><b>${nf.format(r.rowCount)}</b><span>سجل</span></div><div><b>${r.sheetCount}</b><span>ورقة</span></div><div><b>${isManual(r) ? '—' : fmtSize(r.size)}</b><span>الحجم</span></div></div>
      <div class="f-foot"><span>تاريخ الرفع: <span class="date">${new Date(r.createdAt).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}</span></span><span style="color:var(--cyan)">فتح التقرير ←</span></div>`;
    c.onclick = () => go('#/report/' + r.id);
    c.onkeydown = e => { if (e.key === 'Enter') go('#/report/' + r.id); };
    box.append(c);
  });
}

/* ---------- Manual entry page ---------- */
const RECENT = [];
async function showEntry() {
  st.current = null; setNav('entry');
  showView('#entryView'); $('#crumbs').innerHTML = '<b>إدخال يدوي</b>';
  if (!st.reports.some(isManual)) { await req('/api/manual/ensure', { method: 'POST' }); await loadList(); }
  const sel = $('#entryTarget'), prev = sel.value;
  const opts = [];
  const man = st.reports.find(isManual);
  if (man) opts.push(`<option value="${man.id}|0">الإدخال اليدوي — سجلات يدوية (${man.rowCount})</option>`);
  const files = st.reports.filter(r => !isManual(r));
  if (files.length) {
    opts.push('<optgroup label="إضافة إلى ملف مرفوع">');
    for (const r of files) {
      const head = await getReport(r.id);
      head.sheets.forEach((s, si) => opts.push(`<option value="${r.id}|${si}">${esc(r.name)}${head.sheets.length > 1 ? ' / ' + esc(s.name) : ''} (${s.rows.length})</option>`));
    }
    opts.push('</optgroup>');
  }
  sel.innerHTML = opts.join('');
  if (prev && [...sel.options].some(o => o.value === prev)) sel.value = prev;
  dataset().catch(() => {});
  await renderEntryForm(); renderRecent();
}
async function entryTarget() {
  const [id, si] = $('#entryTarget').value.split('|');
  const rep = await getReport(id); rep.sheets.forEach(normalizeSheet);
  return { rep, si: +si };
}
async function renderEntryForm() {
  if (!$('#entryTarget').value) return;
  const { rep, si } = await entryTarget();
  buildForm($('#entryForm'), rep, si, null);
  $('#entryOpen').href = '#/report/' + rep.id;
}
async function saveEntry() {
  const btn = $('#entrySave');
  const row = readForm($('#entryForm'));
  if (row.every(isEmpty)) return toast('أدخل قيمة واحدة على الأقل', true);
  btn.disabled = true;
  try {
    const { rep, si } = await entryTarget();
    const ri = await addRow(rep, si, row);
    RECENT.unshift({ rep, si, row, ri, at: Date.now() });
    toast('تم حفظ السجل — يظهر الآن في لوحة الوكيل وكشف الحساب الشامل');
    const keep = readForm($('#entryForm'));
    buildForm($('#entryForm'), rep, si, null);
    // keep date & agent to speed up repeated entry
    const kinds = JSON.parse($('#entryForm').dataset.kinds), ai = agentIndex(rep, si);
    $('#entryForm').querySelectorAll('input').forEach((inp, i) => { if ((kinds[i] === 'date' || i === ai) && !isEmpty(keep[i])) inp.value = kinds[i] === 'date' ? isoDay(keep[i]) : keep[i]; });
    const opt = $('#entryTarget').selectedOptions[0]; if (opt) opt.textContent = opt.textContent.replace(/\(\d+\)$/, `(${rep.sheets[si].rows.length})`);
    renderRecent();
  } catch (e) { onErr(e); }
  finally { btn.disabled = false; }
}
function rowChips(headers, row) {
  return headers.map((h, i) => isEmpty(row[i]) ? '' : `<span class="chip"><i>${esc(h)}:</i>${esc(fmtCell(row[i], IDLIKE.test(h)))}</span>`).join('');
}
function renderRecent() {
  const box = $('#entryRecent');
  if (!RECENT.length) { box.innerHTML = '<div class="empty">لم تُضف سجلات في هذه الجلسة بعد.</div>'; return; }
  box.innerHTML = '';
  RECENT.slice(0, 20).forEach(x => {
    const ri = x.rep.sheets[x.si].rows.indexOf(x.row);
    const line = el('div', 'rec-line', `<div class="chips">${rowChips(x.rep.sheets[x.si].headers, x.row)}</div>`);
    if (ri < 0) { line.style.opacity = .5; box.append(line); return; }
    const acts = el('div', 'row-acts', `<button type="button" title="تعديل">${ICON_EDIT}</button><button type="button" class="del" title="حذف">${ICON_DEL}</button>`);
    acts.children[0].onclick = () => openRecord(x.rep, x.si, x.rep.sheets[x.si].rows.indexOf(x.row));
    acts.children[1].onclick = () => confirmDelete(x.rep, x.si, x.rep.sheets[x.si].rows.indexOf(x.row));
    line.append(acts); box.append(line);
  });
}

/* ---------- Trash page ---------- */
let TRASH = [];
async function showTrash() {
  st.current = null; setNav('trash');
  showView('#trashView'); $('#crumbs').innerHTML = '<b>السجلات المحذوفة</b>';
  $('#trashList').innerHTML = '<div class="empty-state">جارٍ التحميل…</div>';
  TRASH = (await loadTrashCount()) || [];
  renderTrash();
}
function renderTrash() {
  const q = normAr($('#trashSearch').value || '');
  const list = TRASH.filter(t => !q || normAr(t.reportName + ' ' + t.row.map(v => fmtCell(v)).join(' ')).includes(q));
  $('#trashEmpty').disabled = !TRASH.length;
  const box = $('#trashList');
  if (!list.length) { box.innerHTML = TRASH.length ? emptyState('لا توجد نتائج مطابقة.') : '<div class="empty-state"><b>لا توجد سجلات محذوفة</b>عندما تحذف أي سجل سيظهر هنا ويمكنك استعادته.</div>'; return; }
  box.innerHTML = '';
  list.forEach((t, i) => {
    const it = el('div', 't-item'); it.style.animationDelay = Math.min(i * 30, 400) + 'ms';
    it.innerHTML = `<div><div class="t-meta"><span class="when">${new Date(t.deletedAt).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}</span><span>المصدر: <b>${esc(t.reportName)}</b> / ${esc(t.sheetName)}</span><span>الموضع الأصلي: <b>${t.ri + 1}</b></span>${t.deletedBy ? `<span>بواسطة: <b>${esc(t.deletedBy)}</b></span>` : ''}</div><div class="chips">${rowChips(t.headers, t.row)}</div>${t.reportExists ? '' : '<div class="t-orphan" style="margin-top:8px">ملف هذا السجل محذوف، لذلك لا يمكن استعادته.</div>'}</div>
      <div class="t-acts"><button class="btn" data-a="restore" ${t.reportExists ? '' : 'disabled'}>استعادة</button><button class="btn btn-danger" data-a="purge">حذف نهائي</button></div>`;
    it.querySelector('[data-a=restore]').onclick = async () => {
      try {
        const r = await req(`/api/trash/${t.id}/restore`, { method: 'POST' });
        REPS.delete(r.reportId); if (st.current && st.current.id === r.reportId) st.current = null;
        afterChange(); TRASH = TRASH.filter(x => x !== t); $('#trashCount').textContent = TRASH.length; renderTrash();
        toast(`تمت استعادة السجل إلى «${t.reportName}»`);
      } catch (e) { onErr(e); }
    };
    it.querySelector('[data-a=purge]').onclick = async () => {
      if (!await ask('حذف نهائي؟', 'سيُحذف هذا السجل نهائياً ولا يمكن استعادته بعد ذلك.', 'حذف نهائي')) return;
      try { await req(`/api/trash/${t.id}`, { method: 'DELETE' }); TRASH = TRASH.filter(x => x !== t); $('#trashCount').textContent = TRASH.length; renderTrash(); toast('تم الحذف النهائي'); } catch (e) { onErr(e); }
    };
    box.append(it);
  });
}
async function emptyTrash() {
  if (!TRASH.length || !await ask('حذف كل المحذوفات نهائياً؟', `سيتم حذف ${TRASH.length} سجل نهائياً ولا يمكن استعادتها.`, 'حذف الكل')) return;
  try { await req('/api/trash', { method: 'DELETE' }); TRASH = []; $('#trashCount').textContent = 0; renderTrash(); toast('تم إفراغ السجلات المحذوفة'); } catch (e) { onErr(e); }
}
function setupRecords() {
  $('#recSave').onclick = saveRecord; $('#recCancel').onclick = closeRecord; $('#recClose').onclick = closeRecord;
  $('#recDel').onclick = async () => { if (!REC) return; const { rep, si, ri } = REC; closeRecord(); await confirmDelete(rep, si, ri); };
  $('#recModal').addEventListener('click', e => { if (e.target.id === 'recModal') closeRecord(); });
  $('#recForm').addEventListener('submit', e => { e.preventDefault(); saveRecord(); });
  $('#recForm').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); saveRecord(); } });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { if (!$('#recModal').hidden) closeRecord(); if (!$('#askModal').hidden) $('#askNo').click(); } });
  $('#addRowBtn').onclick = () => st.current && openRecord(st.current, st.sheet, null);
  $('#dataTable').addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b || !st.current) return;
    const ri = +b.dataset.i;
    if (b.dataset.act === 'edit') openRecord(st.current, st.sheet, ri); else confirmDelete(st.current, st.sheet, ri);
  });
  $('#fileSearch').oninput = renderFiles;
  $('#trashSearch').oninput = renderTrash;
  $('#trashEmpty').onclick = emptyTrash;
  $('#entryTarget').onchange = () => renderEntryForm().catch(onErr);
  $('#entrySave').onclick = saveEntry;
  $('#entryClear').onclick = () => renderEntryForm().catch(onErr);
  $('#entryForm').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); saveEntry(); } });
}

let tt; function toast(m, err) { const t = $('#toast'); t.textContent = m; t.classList.toggle('err', !!err); t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 3200); }
function closeSide() { $('#side').classList.remove('open'); $('#sideBackdrop').classList.remove('on'); }
function openSide() { $('#side').classList.add('open'); $('#sideBackdrop').classList.add('on'); }

/* ---------- Agents & Master ledger ---------- */
const headKey = h => normAr(h).replace(/[^\p{L}\p{N} ]/gu, '').split(' ').map(w => w.replace(/^ال(?=..)/, '')).join(' ');
const AGENT_TIERS = [/وكيل|مندوب|agent/i, /عميل|زبون|customer|client/i, /اسم الحساب|الحساب|account|المستفيد/i];
const ROLES = {
  debit: h => /مدين|debit|^عليه$|منه/i.test(h),
  credit: h => /دائن|credit|^له$/i.test(h),
  balance: h => /رصيد|balance/i.test(h),
  amount: h => /مبلغ|المبلغ|إجمالي|اجمالي|القيمه|القيمة|amount|total/i.test(h),
  doc: h => /سند|فاتور|مستند|إيصال|ايصال|voucher|invoice|receipt|ref/i.test(h),
  paid: h => /دفع|مدفوع|واصل|مستلم|paid/i.test(h),
  remaining: h => /متبقي|باقي|remaining|due/i.test(h),
};
const MONEY_RE = /مبلغ|مدين|دائن|إجمالي|اجمالي|كميه|كمية|قيمه|قيمة|دفع|مدفوع|متبقي|باقي|واصل|amount|total|qty|debit|credit|paid|remaining/i;
function detectAgentCol(cols) {
  for (const re of AGENT_TIERS) { const c = cols.find(c => c.type === 'text' && re.test(c.name)); if (c) return c.i; }
  return -1;
}
let DS = null;
function invalidate() { DS = null; }
async function dataset() {
  if (DS) return DS;
  const ids = await req('/api/all');
  const reps = [];
  for (const id of ids) reps.push(await getReport(id));
  const colMap = new Map(); // key -> {key,label,type}
  const recs = [];
  const agents = new Map();
  reps.forEach(rep => {
    rep.sheets.forEach((sh, si) => {
      normalizeSheet(sh);
      const an = analyse(sh);
      const ov = rep.agentCols && rep.agentCols[si];
      const ai = ov !== undefined && ov !== null ? +ov : detectAgentCol(an.cols);
      const keys = sh.headers.map((h, i) => {
        if (i === ai) return null;
        const k = headKey(h) || ('col' + i);
        if (!colMap.has(k)) colMap.set(k, { key: k, label: h, type: an.cols[i].type });
        else if (colMap.get(k).type === 'text' && an.cols[i].type !== 'text') colMap.get(k).type = an.cols[i].type;
        return k;
      });
      const dateCol = an.cols.find(c => c.type === 'date');
      sh.rows.forEach((r, ri) => {
        const cells = {};
        keys.forEach((k, i) => { if (k && !isEmpty(r[i])) cells[k] = r[i]; });
        const raw = ai >= 0 && !isEmpty(r[ai]) ? String(r[ai]).trim().replace(/\s+/g, ' ') : '';
        const akey = raw ? normAr(raw) : '';
        const rec = { rep, sheet: sh.name, si, ri, row: r, cells, agent: raw, akey, date: dateCol ? r[dateCol.i] : null };
        recs.push(rec);
        if (akey) {
          if (!agents.has(akey)) agents.set(akey, { key: akey, names: new Map(), recs: [] });
          const a = agents.get(akey); a.recs.push(rec); a.names.set(raw, (a.names.get(raw) || 0) + 1);
        }
      });
    });
  });
  const cols = [...colMap.values()];
  const role = {};
  for (const r of Object.keys(ROLES)) { const c = cols.find(c => c.type === 'num' && ROLES[r](c.label)); if (c) role[r] = c.key; }
  const dc = cols.find(c => /رقم|no|#/i.test(c.label) && ROLES.doc(c.label)) || cols.find(c => ROLES.doc(c.label));
  if (dc) role.doc = dc.key;
  const pc = cols.find(c => c.type === 'text' && /اسم العامل|العامل|الموظف|اسم|الاسم|worker|name/i.test(c.label));
  if (pc) role.person = pc.key;
  recs.forEach(r => { r.cancelled = Object.values(r.cells).some(v => typeof v === 'string' && /^ملغ(ي|اه)/.test(normAr(v))); });
  agents.forEach(a => {
    a.name = [...a.names.entries()].sort((x, y) => y[1] - x[1])[0][0];
    a.stats = statsOf(a.recs, role);
  });
  DS = { reps, recs, cols, role, agents: [...agents.values()].sort((x, y) => y.recs.length - x.recs.length) };
  $('#agentCount').textContent = DS.agents.length;
  return DS;
}
function statsOf(recs, role) {
  const sum = k => recs.reduce((a, r) => a + (k && toNum(r.cells[k]) || 0), 0);
  const s = { n: recs.length };
  if (role.debit || role.credit) { s.debit = sum(role.debit); s.credit = sum(role.credit); s.balance = s.debit - s.credit; }
  if (role.amount) s.amount = sum(role.amount);
  if (role.doc) s.docs = new Set(recs.map(r => r.cells[role.doc]).filter(v => !isEmpty(v))).size;
  if (role.paid) s.paid = sum(role.paid);
  if (role.remaining) s.remaining = sum(role.remaining);
  if (role.person) s.people = new Set(recs.filter(r => !r.cancelled).map(r => normAr(r.cells[role.person] || '')).filter(Boolean)).size;
  s.cancelled = recs.filter(r => r.cancelled).length;
  const ds = recs.map(r => r.date).filter(d => d instanceof Date && !isNaN(d)).map(Number);
  if (ds.length) { s.first = new Date(amin(ds)); s.last = new Date(amax(ds)); }
  s.files = new Set(recs.map(r => r.rep.id)).size;
  return s;
}
const initial = n => (String(n).trim().match(/\p{L}/u) || ['?'])[0];
const dstr = d => d instanceof Date ? d.toLocaleDateString('en-CA') : '';

function extraKpis(s) {
  const o = [];
  if (s.people != null) o.push({ l: 'عدد الأشخاص / العمال', v: s.people, sub: 'بدون المكرر والملغي' });
  if (s.cancelled) o.push({ l: 'سجلات ملغاة', v: s.cancelled, c: '#ff3b6b' });
  return o;
}
function kpiRow(box, list) {
  box.innerHTML = '';
  list.forEach((x, i) => {
    const d = el('div', 'kpi'); d.style.setProperty('--c', x.c || COLORS[i % COLORS.length]); d.style.animationDelay = (i * 60) + 'ms';
    d.innerHTML = `<div class="kpi-label">${esc(x.l)}</div><div class="kpi-val" ${typeof x.v === 'number' ? `data-v="${x.v}">0` : `>${esc(x.v)}`}</div><div class="kpi-sub">${esc(x.sub || '')}</div>`;
    box.append(d);
  });
  box.querySelectorAll('.kpi-val[data-v]').forEach(countUp);
}
function moneyKpis(s, role) {
  const out = [];
  const lab = k => (DS.cols.find(c => c.key === k) || {}).label || '';
  if (role.paid) out.push({ l: `إجمالي «${lab(role.paid)}»`, v: s.paid, c: '#b6ff3b' });
  if (role.remaining) out.push({ l: `إجمالي «${lab(role.remaining)}»`, v: s.remaining, c: '#ff2bd6' });
  if (role.paid && role.remaining) out.push({ l: 'الإجمالي (مدفوع + متبقي)', v: s.paid + s.remaining, c: '#ffb02e' });
  if (role.debit) out.push({ l: 'إجمالي المدين', v: s.debit, c: '#ff2bd6' });
  if (role.credit) out.push({ l: 'إجمالي الدائن', v: s.credit, c: '#b6ff3b' });
  if (role.debit || role.credit) out.push({ l: 'الرصيد (مدين − دائن)', v: s.balance, sub: s.balance > 0 ? 'رصيد مدين' : s.balance < 0 ? 'رصيد دائن' : 'متوازن', c: '#ffb02e' });
  else if (role.amount && !role.paid) out.push({ l: 'إجمالي المبالغ', v: s.amount, c: '#ffb02e' });
  return out;
}

/* Generic data grid */
function Grid(root, { pageSizes = [25, 50, 100], sortable = true, totals = true, name = 'export' } = {}) {
  const g = { headers: [], types: [], rows: [], cls: [], q: '', page: 0, size: pageSizes[0], sc: -1, sd: 1, noTotal: new Set(), html: [], refs: null, onAct: null };
  root.innerHTML = `<div class="grid-tools"><input type="search" class="table-search" placeholder="بحث داخل البيانات…" aria-label="بحث"><select aria-label="عدد الصفوف">${pageSizes.map(n => `<option value="${n}">${n === Infinity ? 'عرض الكل' : n + ' صف'}</option>`).join('')}</select><button class="btn btn-ghost">تصدير CSV</button></div><div class="table-wrap"><table></table></div><div class="pager"></div>`;
  const [inp, sel, exp] = root.querySelectorAll('.grid-tools > *');
  const table = root.querySelector('table'), pager = root.querySelector('.pager');
  table.addEventListener('click', e => { const b = e.target.closest('[data-act]'); if (b && g.onAct && g.refs) g.onAct(b.dataset.act, g.refs[+b.dataset.i]); });
  inp.oninput = () => { g.q = inp.value; g.page = 0; render(); };
  sel.onchange = () => { g.size = +sel.value || Infinity; g.page = 0; render(); };
  exp.onclick = () => {
    const rows = filtered().map(x => x.r.map(fmtCell));
    const csv = [g.headers, ...rows].map(r => r.map(c => /[",\n]/.test(c) ? `"${String(c).replace(/"/g, '""')}"` : c).join(',')).join('\n');
    const a = el('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' })); a.download = name + '.csv'; a.click();
  };
  function filtered() {
    let rows = g.rows.map((r, i) => ({ r, i }));
    const q = g.q.trim().toLowerCase();
    if (q) rows = rows.filter(x => x.r.some(c => (fmtCell(c) + (typeof c === 'number' ? ' ' + c : '')).toLowerCase().includes(q)));
    if (g.sc >= 0) {
      const c = g.sc, d = g.sd;
      rows.sort((a, b) => { const x = a.r[c], y = b.r[c]; const nx = x instanceof Date ? +x : toNum(x), ny = y instanceof Date ? +y : toNum(y); if (nx !== null && ny !== null) return (nx - ny) * d; if (isEmpty(x)) return 1; if (isEmpty(y)) return -1; return String(x).localeCompare(String(y), 'ar') * d; });
    }
    return rows;
  }
  function render() {
    const rows = filtered(), size = g.size === Infinity ? Math.max(1, rows.length) : g.size;
    const pages = Math.max(1, Math.ceil(rows.length / size)); g.page = Math.min(g.page, pages - 1);
    const slice = rows.slice(g.page * size, g.page * size + size);
    const q = g.q.trim(); const re = q ? new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi') : null;
    const hl = t => { const e = esc(t); return re ? e.replace(re, '<mark>$1</mark>') : e; };
    let h = '<thead><tr><th>#</th>' + g.headers.map((x, i) => `<th data-c="${i}" class="${g.sc === i ? 'sorted' : ''}">${esc(x)}${sortable ? `<span class="arr">${g.sc === i ? (g.sd > 0 ? '▲' : '▼') : '⇅'}</span>` : ''}</th>`).join('') + (g.refs ? '<th class="row-acts">إجراءات</th>' : '') + '</tr></thead><tbody>';
    if (!slice.length) h += `<tr><td colspan="${g.headers.length + 2}" class="no-rows">لا توجد بيانات مطابقة</td></tr>`;
    slice.forEach(({ r, i }) => {
      h += `<tr><td class="idx">${i + 1}</td>` + r.map((c, j) => {
        const custom = g.html[j] && g.html[j](c, g.rows[i]);
        const raw = IDLIKE.test(g.headers[j]);
        const cls = [g.types[j] !== 'text' ? 'num' : '', g.cls[j] || '', g.cls[j] === 'bal' && toNum(c) < 0 ? 'neg' : ''].join(' ');
        return `<td class="${cls}" title="${esc(fmtCell(c, raw))}">${custom != null ? custom : hl(fmtCell(c, raw))}</td>`;
      }).join('') + (g.refs ? actCell(i) : '') + '</tr>';
    });
    h += '</tbody>';
    if (totals && g.types.some((t, j) => t === 'num' && !g.noTotal.has(j)) && rows.length) {
      h += '<tfoot><tr><td>Σ</td>' + g.headers.map((_, j) => {
        if (g.types[j] !== 'num' || g.noTotal.has(j)) return j === 0 ? '<td>الإجمالي</td>' : '<td></td>';
        return `<td class="num">${nf.format(rows.reduce((a, x) => a + (toNum(x.r[j]) || 0), 0))}</td>`;
      }).join('') + (g.refs ? '<td></td>' : '') + '</tr></tfoot>';
    }
    table.innerHTML = h;
    if (sortable) table.querySelectorAll('th[data-c]').forEach(th => th.onclick = () => { const c = +th.dataset.c; if (g.sc === c) g.sd *= -1; else { g.sc = c; g.sd = 1; } render(); });
    const from = rows.length ? g.page * size + 1 : 0, to = Math.min(rows.length, (g.page + 1) * size);
    pager.innerHTML = `<span>عرض ${from}–${to} من ${rows.length} سجل</span><div class="pg"><button class="btn" data-p="-1" ${g.page === 0 ? 'disabled' : ''}>السابق</button><span style="align-self:center;font-family:var(--font-m)">${g.page + 1} / ${pages}</span><button class="btn" data-p="1" ${g.page >= pages - 1 ? 'disabled' : ''}>التالي</button></div>`;
    pager.querySelectorAll('button').forEach(b => b.onclick = () => { g.page += +b.dataset.p; render(); root.querySelector('.table-wrap').scrollTop = 0; });
  }
  return {
    set(o, keep) { if (keep) Object.assign(g, { cls: [], html: [], noTotal: new Set(), refs: null }, o); else { Object.assign(g, { cls: [], html: [], noTotal: new Set(), refs: null }, o, { page: 0, sc: -1, q: '' }); inp.value = ''; } render(); },
  };
}

let agentsGrid, ledgerGrid, aChart;
function hideViews() { document.querySelectorAll('.main > .view').forEach(v => v.classList.add('hidden')); }
function showView(id) { hideViews(); const v = $(id); v.classList.remove('hidden'); restartAnim(v); window.scrollTo({ top: 0 }); closeSide(); }
function setNav(n) { document.querySelectorAll('.nav-item').forEach(a => a.classList.toggle('active', a.dataset.nav === n)); }
function emptyState(msg) { return `<div class="empty-state"><b>لا توجد بيانات بعد</b>${msg}</div>`; }

async function showAgents() {
  st.current = null; renderList(); setNav('agents');
  showView('#agentsView'); $('#crumbs').innerHTML = '<b>لوحات الوكلاء</b>';
  const ds = await dataset();
  const tot = statsOf(ds.recs.filter(r => r.akey), ds.role);
  kpiRow($('#agentsKpis'), [
    { l: 'عدد الوكلاء', v: ds.agents.length, sub: 'تم اكتشافهم تلقائياً' },
    { l: 'عمليات الوكلاء', v: tot.n, sub: `من ${ds.reps.length} ملف` },
    ...(tot.docs != null ? [{ l: 'عدد السندات', v: tot.docs }] : []),
    ...moneyKpis(tot, ds.role), ...extraKpis(tot),
  ]);
  renderAgentCards();
}
function renderAgentCards() {
  const ds = DS, box = $('#agentGrid'), q = normAr($('#agentSearch').value || '');
  if (!ds.agents.length) { box.innerHTML = emptyState(ds.recs.length ? 'لم يُعثر على عمود للوكلاء في الملفات. افتح أي تقرير واختر «عمود الوكيل» يدوياً.' : 'ارفع ملف إكسل يحتوي على عمود «الوكيل» أو «العميل» وسيُنشئ النظام صفحة لكل وكيل.'); box.style.display = 'block'; return; }
  box.style.display = '';
  const list = ds.agents.filter(a => !q || a.key.includes(q));
  box.innerHTML = list.length ? '' : emptyState('لا يوجد وكيل بهذا الاسم.');
  list.forEach((a, i) => {
    const s = a.stats, card = el('a', 'agent-card'); card.href = '#/agent/' + encodeURIComponent(a.key); card.style.animationDelay = Math.min(i * 35, 600) + 'ms';
    let money = '';
    if (s.paid != null || s.remaining != null) money = (s.paid != null ? `<div class="ac-stat pos"><b>${compact.format(s.paid)}</b><span>مدفوع</span></div>` : '') + (s.remaining != null ? `<div class="ac-stat neg"><b>${compact.format(s.remaining)}</b><span>متبقي</span></div>` : '') + (s.people != null ? `<div class="ac-stat"><b>${s.people}</b><span>عامل</span></div>` : '');
    else if (s.balance != null) money = `<div class="ac-stat ${s.balance > 0 ? 'neg' : s.balance < 0 ? 'pos' : ''}"><b>${nf.format(s.balance)}</b><span>الرصيد</span></div>`;
    else if (s.amount != null) money = `<div class="ac-stat"><b>${nf.format(s.amount)}</b><span>إجمالي المبالغ</span></div>`;
    else money = `<div class="ac-stat"><b>${s.files}</b><span>ملفات</span></div>`;
    card.innerHTML = `<div class="ac-top"><div class="avatar">${esc(initial(a.name))}</div><div><div class="ac-name">${esc(a.name)}</div><div class="ac-sub">${s.last ? 'آخر عملية ' + dstr(s.last) : s.files + ' ملف'}</div></div></div><div class="ac-stats"><div class="ac-stat"><b>${s.n}</b><span>عملية${s.docs != null ? ' · ' + s.docs + ' سند' : ''}</span></div>${money}</div>`;
    box.append(card);
  });
}

async function showAgent(key, keep) {
  st.current = null; renderList(); setNav('agents');
  const ds = await dataset();
  const a = ds.agents.find(x => x.key === key);
  if (!a) { location.hash = '#/agents'; return; }
  if (!keep) showView('#agentView'); $('#crumbs').innerHTML = `<a href="#/agents" style="color:inherit">الوكلاء</a> / <b>${esc(a.name)}</b>`;
  const s = a.stats, role = ds.role;
  $('#aAvatar').textContent = initial(a.name); $('#aName').textContent = a.name;
  const variants = [...a.names.keys()].filter(n => n !== a.name);
  $('#aMeta').innerHTML = `<span>عدد العمليات: <b>${s.n}</b></span><span>الملفات: <b>${s.files}</b></span>${s.first ? `<span>الفترة: <b>${dstr(s.first)} ← ${dstr(s.last)}</b></span>` : ''}${variants.length ? `<span>صيغ أخرى للاسم: <b>${esc(variants.join('، '))}</b></span>` : ''}`;
  kpiRow($('#aKpis'), [
    { l: 'عدد العمليات', v: s.n, sub: `في ${s.files} ملف` },
    ...(s.docs != null ? [{ l: 'عدد السندات', v: s.docs }] : []),
    ...moneyKpis(s, role), ...extraKpis(s),
  ]);
  // sources
  const src = new Map(); a.recs.forEach(r => { const k = r.rep.name + ' — ' + r.sheet; src.set(k, (src.get(k) || 0) + 1); });
  $('#aSources').innerHTML = [...src.entries()].map(([k, n]) => `<div class="cs"><div class="cs-name" title="${esc(k)}">${esc(k)}</div><span class="cs-type t-num">${n}</span><div class="cs-stats">${n} records</div></div>`).join('');
  // statement rows sorted by date (stable)
  const recs = a.recs.map((r, i) => ({ r, i })).sort((x, y) => {
    const dx = x.r.date instanceof Date ? +x.r.date : null, dy = y.r.date instanceof Date ? +y.r.date : null;
    if (dx !== null && dy !== null && dx !== dy) return dx - dy; return x.i - y.i;
  }).map(x => x.r);
  const cols = ds.cols.filter(c => recs.some(r => !isEmpty(r.cells[c.key])));
  const headers = ['المصدر', ...cols.map(c => c.label)], types = ['text', ...cols.map(c => c.type)], cls = ['src'];
  const hasDC = role.debit || role.credit;
  if (hasDC) { headers.push('الرصيد التراكمي'); types.push('num'); }
  let run = 0;
  const rows = recs.map(r => {
    const row = [r.rep.name + ' / ' + r.sheet, ...cols.map(c => r.cells[c.key] ?? '')];
    if (hasDC) { run += (toNum(r.cells[role.debit]) || 0) - (toNum(r.cells[role.credit]) || 0); row.push(+run.toFixed(2)); }
    return row;
  });
  const noTotal = new Set(); cols.forEach((c, i) => { if (c.key === role.balance || !MONEY_RE.test(c.label)) noTotal.add(i + 1); });
  if (hasDC) { noTotal.add(headers.length - 1); cls[headers.length - 1] = 'bal'; }
  if (!agentsGrid) agentsGrid = Grid($('#aGrid'), { pageSizes: [50, 100, Infinity] });
  agentsGrid.set({ headers, types, rows, cls, noTotal, name: 'كشف-' + a.name, refs: recs, onAct: recAct }, keep);
  drawAgentChart(recs, role);
}
function drawAgentChart(recs, role) {
  const m = new Map();
  recs.forEach(r => {
    const k = r.date instanceof Date && !isNaN(r.date) ? r.date.getFullYear() + '-' + String(r.date.getMonth() + 1).padStart(2, '0') : 'بدون تاريخ';
    const o = m.get(k) || { d: 0, c: 0, a: 0, n: 0, p: 0, r: 0 };
    o.p += toNum(r.cells[role.paid]) || 0; o.r += toNum(r.cells[role.remaining]) || 0;
    o.d += toNum(r.cells[role.debit]) || 0; o.c += toNum(r.cells[role.credit]) || 0; o.a += toNum(r.cells[role.amount]) || 0; o.n++;
    m.set(k, o);
  });
  const keys = [...m.keys()].sort();
  const sets = role.paid || role.remaining
    ? [...(role.paid ? [{ label: 'مدفوع', data: keys.map(k => m.get(k).p), backgroundColor: 'rgba(182,255,59,.6)', borderColor: '#b6ff3b' }] : []), ...(role.remaining ? [{ label: 'متبقي', data: keys.map(k => m.get(k).r), backgroundColor: 'rgba(255,43,214,.7)', borderColor: '#ff2bd6' }] : [])]
    : role.debit || role.credit
    ? [{ label: 'مدين', data: keys.map(k => m.get(k).d), backgroundColor: 'rgba(255,43,214,.75)', borderColor: '#ff2bd6' }, { label: 'دائن', data: keys.map(k => m.get(k).c), backgroundColor: 'rgba(182,255,59,.6)', borderColor: '#b6ff3b' }]
    : role.amount ? [{ label: 'المبالغ', data: keys.map(k => m.get(k).a), backgroundColor: 'rgba(34,243,255,.6)', borderColor: '#22f3ff' }]
    : [{ label: 'عدد العمليات', data: keys.map(k => m.get(k).n), backgroundColor: 'rgba(34,243,255,.6)', borderColor: '#22f3ff' }];
  sets.forEach(s => { s.borderWidth = 1.5; s.borderRadius = 6; });
  if (aChart) aChart.destroy();
  aChart = new Chart($('#aChart'), { type: 'bar', data: { labels: keys, datasets: sets }, options: {
    responsive: true, maintainAspectRatio: false, animation: { duration: 1000, easing: 'easeOutQuart' },
    plugins: { legend: { display: sets.length > 1, position: 'bottom', rtl: true, labels: { color: '#cfcaf5', boxWidth: 12 } }, tooltip: { rtl: true, backgroundColor: '#100d22', borderColor: '#22f3ff', borderWidth: 1, callbacks: { label: c => ' ' + c.dataset.label + ': ' + nf.format(c.parsed.y) } } },
    scales: { x: { reverse: true, ticks: { color: '#9a94c4', font: { family: 'JetBrains Mono', size: 11 } }, grid: { color: 'rgba(140,120,255,.07)' } }, y: { position: 'right', ticks: { color: '#9a94c4', font: { family: 'JetBrains Mono', size: 11 }, callback: v => compact.format(v) }, grid: { color: 'rgba(140,120,255,.1)' } } },
  } });
}

async function showLedger(keep) {
  st.current = null; renderList(); setNav('ledger');
  if (!keep) showView('#ledgerView'); $('#crumbs').innerHTML = '<b>كشف الحساب الشامل</b>';
  const ds = await dataset();
  const s = statsOf(ds.recs, ds.role);
  kpiRow($('#lKpis'), [
    { l: 'إجمالي العمليات', v: s.n, sub: `من ${ds.reps.length} ملف` },
    { l: 'عدد الوكلاء والعملاء', v: ds.agents.length },
    ...(s.docs != null ? [{ l: 'عدد السندات', v: s.docs }] : []),
    ...moneyKpis(s, ds.role), ...extraKpis(s),
  ]);
  if (!ds.recs.length) { $('#lGrid').innerHTML = emptyState('ارفع ملفات الإكسل لتظهر هنا كل العمليات مجمّعة.'); ledgerGrid = null; return; }
  const headers = ['المصدر', 'الوكيل / العميل', ...ds.cols.map(c => c.label)];
  const types = ['text', 'text', ...ds.cols.map(c => c.type)];
  const rows = ds.recs.map(r => [r.rep.name + ' / ' + r.sheet, r.agent, ...ds.cols.map(c => r.cells[c.key] ?? '')]);
  const noTotal = new Set(); ds.cols.forEach((c, i) => { if (c.key === ds.role.balance || !MONEY_RE.test(c.label)) noTotal.add(i + 2); });
  const html = []; html[1] = v => v ? `<a href="#/agent/${encodeURIComponent(normAr(v))}">${esc(v)}</a>` : '<span style="color:var(--faint)">—</span>';
  if (!document.querySelector('#lGrid .grid-tools')) ledgerGrid = Grid($('#lGrid'), { pageSizes: [100, 500, Infinity], sortable: false, name: 'كشف-الحساب-الشامل' });
  ledgerGrid.set({ headers, types, rows, cls: ['src', 'agent'], noTotal, html, refs: ds.recs, onAct: recAct }, keep);
}

/* agent-column override in report view */
function setupAgentColSel() {
  const r = st.current, sh = r.sheets[st.sheet], cols = st.analysis.cols;
  const auto = detectAgentCol(cols), ov = r.agentCols && r.agentCols[st.sheet];
  const cur = ov !== undefined && ov !== null ? +ov : auto;
  const sel = $('#agentColSel');
  sel.innerHTML = `<option value="-1">— لا يوجد —</option>` + cols.filter(c => c.type === 'text').map(c => `<option value="${c.i}">${esc(c.name)}</option>`).join('');
  sel.value = String(cur);
  $('#agentColHint').textContent = cur >= 0 ? `سيتم توزيع ${sh.rows.length} سجل على صفحات الوكلاء حسب «${sh.headers[cur]}»` + (ov == null ? ' (اكتشاف تلقائي)' : '') : 'لن تُضاف سجلات هذه الورقة إلى صفحات الوكلاء';
}
async function changeAgentCol() {
  const r = st.current; r.agentCols = r.agentCols || {};
  r.agentCols[st.sheet] = +$('#agentColSel').value;
  await req('/api/reports/' + encodeURIComponent(r.id) + '/agentcols', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(r.agentCols) });
  invalidate(); setupAgentColSel(); dataset().catch(() => {}); toast('تم تحديث عمود الوكيل');
}

function recAct(act, rec) {
  if (!rec) return;
  const ri = rec.rep.sheets[rec.si].rows.indexOf(rec.row);
  if (ri < 0) return toast('هذا السجل تغيّر، أعد تحميل الصفحة', true);
  if (act === 'edit') openRecord(rec.rep, rec.si, ri); else confirmDelete(rec.rep, rec.si, ri);
}
function route() {
  if (!AUTH.token) return;
  const h = decodeURIComponent(location.hash.slice(1) || '/');
  const [, view, ...rest] = h.split('/'); const arg = rest.join('/');
  if (view === 'agents') return showAgents().catch(onErr);
  if (view === 'agent') return showAgent(arg).catch(onErr);
  if (view === 'ledger') return showLedger().catch(onErr);
  if (view === 'report' && arg) return openReport(arg).catch(onErr);
  if (view === 'files') return showFiles().catch(onErr);
  if (view === 'entry') return showEntry().catch(onErr);
  if (view === 'trash') return showTrash().catch(onErr);
  showUpload();
}
function go(h) { if (location.hash === h) route(); else location.hash = h; }
function onErr(e) { console.error(e); toast('تعذّر تحميل البيانات من الخادم', true); }

/* ---------- Background: neon perspective grid + particles ---------- */
function bg() {
  const c = $('#bg'), x = c.getContext('2d');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let w, h, dpr, parts = [];
  const resize = () => {
    dpr = Math.min(2, devicePixelRatio || 1); w = innerWidth; h = innerHeight;
    c.width = w * dpr; c.height = h * dpr; c.style.width = w + 'px'; c.style.height = h + 'px'; x.setTransform(dpr, 0, 0, dpr, 0, 0);
    parts = Array.from({ length: Math.round(w / 28) }, () => ({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * 1.6 + .3, v: Math.random() * .3 + .08, c: COLORS[Math.floor(Math.random() * 4)] }));
  };
  resize(); addEventListener('resize', resize);
  let t = 0;
  const frame = () => {
    x.clearRect(0, 0, w, h);
    const hor = h * .62, cx = w / 2;
    // horizon glow
    const g = x.createLinearGradient(0, hor - 60, 0, hor + 40); g.addColorStop(0, 'rgba(255,43,214,0)'); g.addColorStop(.6, 'rgba(255,43,214,.10)'); g.addColorStop(1, 'rgba(255,43,214,0)');
    x.fillStyle = g; x.fillRect(0, hor - 60, w, 100);
    x.lineWidth = 1;
    // vertical lines
    for (let i = -24; i <= 24; i++) {
      x.strokeStyle = `rgba(157,92,255,${.10 - Math.abs(i) * .003})`;
      x.beginPath(); x.moveTo(cx + i * 20, hor); x.lineTo(cx + i * 160, h); x.stroke();
    }
    // horizontal lines moving
    const off = (t * .6) % 1;
    for (let i = 0; i < 14; i++) {
      const p = (i + off) / 14, y = hor + Math.pow(p, 2.2) * (h - hor);
      x.strokeStyle = `rgba(34,243,255,${.03 + p * .12})`;
      x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke();
    }
    // particles
    parts.forEach(p => {
      p.y -= p.v; if (p.y < -5) { p.y = h + 5; p.x = Math.random() * w; }
      x.beginPath(); x.arc(p.x, p.y, p.r, 0, 7); x.fillStyle = p.c; x.shadowColor = p.c; x.shadowBlur = 8; x.globalAlpha = .55; x.fill();
    });
    x.globalAlpha = 1; x.shadowBlur = 0;
    t += .01;
    if (!reduce) requestAnimationFrame(frame);
  };
  frame();
}

/* ---------- Init ---------- */
function init() {
  bg();
  const drop = $('#drop'), fi = $('#fileInput');
  fi.onchange = e => handleFile(e.target.files[0]);
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => handleFile(e.dataTransfer.files[0]));
  drop.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fi.click(); } });
  $('#newBtn').onclick = () => go('#/upload');
  $('#agentSearch').oninput = () => DS && renderAgentCards();
  $('#agentColSel').onchange = () => changeAgentCol().catch(onErr);
  $('#aPrint').onclick = $('#lPrint').onclick = () => print();
  addEventListener('hashchange', route);
  $('#demoBtn').onclick = demo;
  $('#tableSearch').oninput = e => { st.q = e.target.value; st.page = 0; renderTable(); };
  ['#labelCol', '#valueCol', '#chartType'].forEach(s => $(s).onchange = drawChart);
  $('#exportBtn').onclick = exportCsv;
  $('#printBtn').onclick = () => print();
  $('#deleteBtn').onclick = deleteReport;
  $('#menuBtn').onclick = () => $('#side').classList.contains('open') ? closeSide() : openSide();
  $('#sideClose').onclick = closeSide;
  $('#sideBackdrop').onclick = closeSide;
  addEventListener('keydown', e => { if (e.key === 'Escape') closeSide(); });
  document.querySelectorAll('.nav-item').forEach(a => a.addEventListener('click', closeSide));
  const clk = () => $('#clock').textContent = new Date().toLocaleString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit', day: '2-digit', month: 'short' });
  clk(); setInterval(clk, 1000);
  if (window.Chart) { Chart.defaults.color = '#9a94c4'; Chart.defaults.font.family = 'IBM Plex Sans Arabic'; }
  setupRecords();
  setupAuth();
}
document.addEventListener('DOMContentLoaded', init);
})();
